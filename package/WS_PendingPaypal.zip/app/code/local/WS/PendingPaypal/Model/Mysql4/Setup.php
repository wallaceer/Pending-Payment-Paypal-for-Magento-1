<?php
/**
 * Track Setup
 *
 * @category WS
 * @package  WS_PendingPaypal
 * @author
 */
class WS_PendingPaypal_Model_Mysql4_Setup extends Mage_Catalog_Model_Resource_Eav_Mysql4_Setup
{
}
